# STEM Career Planner
Welcome to the STEM Career Planner project! This application will help the user search for a career, based off numerous STEM Careers best related to a users interest and goals.

## Description
Our application allows the user to select a STEM career path. Every part of the career planner will help choosing your career with the following:
* Choose a hobby that best interest you
* Choose your major that you are currently in at your institution 
* based on the choices provided by the user career results may vary
* background knowledge on how to get started with the career today!
